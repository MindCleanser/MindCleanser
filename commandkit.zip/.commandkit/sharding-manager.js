import { ShardingManager } from "discord.js";
import { Logger } from "commandkit";
import { join } from "node:path";

//#region src/sharding-manager.js
process.loadEnvFile("./.env");
const manager = new ShardingManager(join(import.meta.dirname, "index.js"), {
	token: process.env.DISCORD_TOKEN,
	totalShards: "auto",
	mode: "worker"
});
manager.on("shardCreate", (shard) => Logger.info(`Launched shard ${shard.id}`));
await manager.spawn();

//#endregion
//# sourceMappingURL=sharding-manager.js.map