import { __esm, __export } from "./_virtual/rolldown_runtime.js";

//#region contrib.json
var contrib_exports = {};
__export(contrib_exports, {
	contrib: () => contrib,
	default: () => contrib_default
});
var contrib, contrib_default;
var init_contrib = __esm({ "contrib.json"() {
	contrib = "## 1. Boolean44 repos (lead dev) \n ## 2. .digitalapotheosis. (pfp artist)\n ## 3. twrecks64 (pointed me to NAMI)";
	contrib_default = { contrib };
} });

//#endregion
init_contrib();
export { contrib_exports, init_contrib };
//# sourceMappingURL=contrib.js.map