import { __toCommonJS } from "../../_virtual/rolldown_runtime.js";
import { config_exports, init_config } from "../../config.js";
import { ApplicationCommandOptionType, ButtonStyle, ContainerBuilder, MessageFlags } from "discord.js";

//#region src/app/commands/support-server.js
const { discinv } = (init_config(), __toCommonJS(config_exports));
/**
* @type {import('commandkit').CommandData}
*/
const command = {
	name: "support-server",
	description: "Sends support server invite",
	options: [{
		name: "private",
		description: "Can others see this message?",
		type: ApplicationCommandOptionType.Boolean,
		required: true
	}]
};
/**
* @param {import('commandkit').ChatInputCommandContext} ctx
*/
const chatInput = async ({ interaction }) => {
	const hide = interaction.options.getBoolean("private");
	const embed = new ContainerBuilder().addSectionComponents((section) => section.addTextDisplayComponents((textDisplay) => textDisplay.setContent("# __Support server__"), (textDisplay) => textDisplay.setContent("## Click here to join the support server (NOT a mental health support server)")).setButtonAccessory((button) => button.setLabel("Support Server").setStyle(ButtonStyle.Link).setURL(discinv)));
	if (hide == false) {
		const reply = interaction.reply({
			withResponse: true,
			components: [embed],
			flags: MessageFlags.IsComponentsV2
		});
		const message = (await reply).resource.message;
	} else {
		const reply = interaction.reply({
			withResponse: true,
			components: [embed],
			flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2]
		});
		const message = (await reply).resource.message;
	}
};

//#endregion
export { chatInput, command };
//# sourceMappingURL=support-server.js.map