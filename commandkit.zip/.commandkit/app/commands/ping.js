import { ApplicationCommandOptionType, ContainerBuilder, MessageFlags } from "discord.js";

//#region src/app/commands/ping.js
/**
* @type {import('commandkit').CommandData}
*/
const command = {
	name: "ping",
	description: "Sends bot ping",
	options: [{
		name: "private",
		description: "Can others see this message?",
		type: ApplicationCommandOptionType.Boolean,
		required: true
	}]
};
/**
* @param {import('commandkit').ChatInputCommandContext} ctx
*/
const chatInput = async ({ interaction }) => {
	const hide = interaction.options.getBoolean("private");
	const latency = Math.round(interaction.client.ws.ping);
	const embed = new ContainerBuilder().addTextDisplayComponents((textDisplay) => textDisplay.setContent("# __Latency__"), (textDisplay) => textDisplay.setContent(`## ${latency}`));
	if (hide == false) await interaction.reply({
		components: [embed],
		flags: MessageFlags.IsComponentsV2
	});
	else await interaction.reply({
		components: [embed],
		flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2]
	});
};

//#endregion
export { chatInput, command };
//# sourceMappingURL=ping.js.map