import { __toCommonJS } from "../../_virtual/rolldown_runtime.js";
import { config_exports, init_config } from "../../config.js";
import { ApplicationCommandOptionType, ButtonBuilder, ButtonStyle, ContainerBuilder, MessageFlags } from "discord.js";

//#region src/app/commands/nami.js
const { namiweb, namidonate, namithumb, namiresources } = (init_config(), __toCommonJS(config_exports));
/**
* @type {import('commandkit').CommandData}
*/
const command = {
	name: "nami",
	description: "Displays info on NAMI",
	options: [{
		name: "private",
		description: "Can others see this message?",
		type: ApplicationCommandOptionType.Boolean,
		required: true
	}]
};
/**
* @param {import('commandkit').ChatInputCommandContext} ctx
*/
const chatInput = async ({ interaction }) => {
	const hide = interaction.options.getBoolean("private");
	const embed = new ContainerBuilder().addSectionComponents((section) => section.addTextDisplayComponents((textDisplay) => textDisplay.setContent("# __NAMI__"), (textDisplay) => textDisplay.setContent("## NAMI is a large collection of mental health resources on a variety of different topics including mens mental health resources")).setThumbnailAccessory((thumbnail) => thumbnail.setURL(namithumb))).addSeparatorComponents((separator) => separator).addSectionComponents((section) => section.addTextDisplayComponents((textDisplay) => textDisplay.setContent("# __Donate__"), (textDisplay) => textDisplay.setContent("## Click here to donate")).setButtonAccessory((button) => button.setLabel("Donate").setStyle(ButtonStyle.Link).setURL(namidonate))).addSeparatorComponents((separator) => separator).addSeparatorComponents((separator) => separator).addSectionComponents((section) => section.addTextDisplayComponents((textDisplay) => textDisplay.setContent("# __Resources__"), (textDisplay) => textDisplay.setContent("## Click here to view mental health resources")).setButtonAccessory((button) => button.setLabel("Resources").setStyle(ButtonStyle.Link).setURL(namiresources))).addSeparatorComponents((separator) => separator).addSectionComponents((section) => section.addTextDisplayComponents((textDisplay) => textDisplay.setContent("# __Website__"), (textDisplay) => textDisplay.setContent("## Click here to view NAMI's website")).setButtonAccessory((button) => button.setLabel("NAMI").setStyle(ButtonStyle.Link).setURL(namiweb)));
	if (hide == false) {
		const reply = interaction.reply({
			withResponse: true,
			components: [embed],
			flags: MessageFlags.IsComponentsV2
		});
		const message = (await reply).resource.message;
	} else {
		const reply = interaction.reply({
			withResponse: true,
			components: [embed],
			flags: [MessageFlags.Ephemeral, MessageFlags.IsComponentsV2]
		});
		const message = (await reply).resource.message;
	}
};

//#endregion
export { chatInput, command };
//# sourceMappingURL=nami.js.map