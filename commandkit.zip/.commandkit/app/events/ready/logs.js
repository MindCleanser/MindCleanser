import { ActivityType, ShardingManager } from "discord.js";
import "commandkit/logger";
import { createDjsClient } from "discordbotlist";

//#region src/app/events/ready/logs.js
process.loadEnvFile("./.env");
/**
* @param {import('discord.js').Client<true>} client
*/
function log(client, shard, Shard) {
	client.shard.fetchClientValues("guilds.cache.size").then((results) => {
		client.user.setActivity({
			name: `in ${results.reduce((acc, guildCount) => acc + guildCount, 0)} servers`,
			type: ActivityType.Streaming,
			url: "https://www.twitch.tv/mindcleanser"
		});
	}).catch(console.error);
	const dbl = new createDjsClient(process.env.DBLTOKEN, client);
	dbl.startPosting();
	dbl.postBotCommands([{
		name: "help",
		description: "View a list of the bot's commands."
	}]);
}

//#endregion
export { log as default };
//# sourceMappingURL=logs.js.map