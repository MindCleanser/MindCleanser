import { Client } from "discord.js";
import { AutoPoster } from "topgg-autoposter";
import { Logger } from "commandkit";

//#region src/app.js
process.loadEnvFile("./.env");
const client = new Client({ intents: ["Guilds"] });
const ap = AutoPoster(process.env.TOPGGTOKEN, client);
ap.on("posted", () => {
	Logger.info("Posted stats to Top.gg!");
});
var app_default = client;

//#endregion
export { app_default as default };
//# sourceMappingURL=app.js.map